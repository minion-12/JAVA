//3.Multiply Two Floating-Point Numbers

public class MultiplyFloat {
    public static void main(String[] args) {
        float num1 = 2.5f;
        float num2 = 4.2f;

        float product = num1 * num2;

        System.out.println("The product is: " + product);
    }
}